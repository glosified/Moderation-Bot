exports.Prefix = `Prefix`;
exports.Token = `Bot Token`;
exports.Color = `RANDOM`;
